import{b as a,c as b}from"./chunk-WH2HIQK6.js";import"./chunk-2R6CW7ES.js";export{a as GESTURE_CONTROLLER,b as createGesture};
